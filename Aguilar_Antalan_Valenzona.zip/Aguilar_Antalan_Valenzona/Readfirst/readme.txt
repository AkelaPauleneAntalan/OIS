

1. Run http://127.0.0.1/ois/createdb.php on your browser.
2. Run http://127.0.0.1/ois/createTable.php on your browser
to create the necessary tables in the system And run insert.php
3. Run http://127.0.0.1/ois/categories.php on your browser and the ouput must be:
"Festivals and Fairs, Seminars and Lectures, Charities, Fashion, 
Sports and Active Life, and Night Life categories added successfully"
4. Run http://127.0.0.1/ois/admin.php on your browser to create an admin account.
5. Run http://127.0.0.1/ois/welcomeUser.php on your browser and log in the
admin account. Username: admin1 Password: admin1
6. In http://127.0.0.1/ois/welcomeUser.php you can also create an account
by signing up (dili mugana ang confirm password)

unta tama ang instructions

Note: The image page is only able to upload and store the image only.
Note: The video have some interruptions kay nagslow akong laptop hehehe 
